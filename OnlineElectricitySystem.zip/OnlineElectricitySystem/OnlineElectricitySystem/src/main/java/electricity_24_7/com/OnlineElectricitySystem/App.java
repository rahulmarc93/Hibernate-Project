package electricity_24_7.com.OnlineElectricitySystem;

import electricity_24_7.com.OnlineElectricitySystem.entity.Bill;
import electricity_24_7.com.OnlineElectricitySystem.entity.CustomerRegistration;
import electricity_24_7.com.OnlineElectricitySystem.entity.ElectricityUsage;
import electricity_24_7.com.OnlineElectricitySystem.entity.PaymentHistory;
import electricity_24_7.com.OnlineElectricitySystem.service.AdminService;
import electricity_24_7.com.OnlineElectricitySystem.service.BillService;
import electricity_24_7.com.OnlineElectricitySystem.service.CustomerService;
import electricity_24_7.com.OnlineElectricitySystem.service.ElectricityUsageService;
import electricity_24_7.com.OnlineElectricitySystem.service.PaymentHistoryService;

import java.util.List;
import java.util.Scanner;

public class App {
  //  private static AdminService adminService;
	private static final AdminService adminService = new AdminService();
    private static final CustomerService customerService = new CustomerService();
    private static final BillService billService = new BillService();
    private static final PaymentHistoryService paymentHistoryService = new PaymentHistoryService();
    private static final ElectricityUsageService electricityUsageService = new ElectricityUsageService();
    private static CustomerRegistration loggedInCustomer;


	public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
      
        while (true) {
 
        	System.out.println("==========================================");
            System.out.println("     Welcome to Online Electricity System");
            System.out.println("==========================================");
            System.out.println("1. Admin Login");
            System.out.println("2. Customer Login");
            System.out.println("3. New Customer Registration");
            System.out.println("4. Exit");
            System.out.print("Enter your choice (1-4): ");
            
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline
            
            switch (choice) {
                case 1:
                	 handleAdminLogin(scanner,adminService);
                    break;

                case 2:
                	handleCustomerLogin(scanner);
                    break;

                case 3:
                    handleCustomerRegistration(scanner, customerService);
                    break;

                case 4:
                    System.out.println("Exiting the system. Goodbye!");
                    scanner.close();
                    System.exit(0);
                    break;

                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }
    
    private static void handleAdminLogin(Scanner scanner, AdminService adminService) {
    	System.out.println("==========================================");
        System.out.println("              Admin Login");
        System.out.println("==========================================");
        System.out.print("Enter Admin Username: ");
        String username = scanner.nextLine();
        System.out.print("Enter Password: ");
        String password = scanner.nextLine();

        if (AdminService.validateAdmin(username, password)) {
            System.out.println("Login Successful");
            System.out.println("Welcome, Admin!!!");
            // Call Admin Dashboard or next feature here
            displayAdminDashboard(scanner);
        } else {
            System.out.println("Invalid username or password. Please try again.");
        }    	
    }
    
    private static void displayAdminDashboard(Scanner scanner) {
        while (true) {
            System.out.println("\n==========================================");
            System.out.println("             Admin Dashboard");
            System.out.println("==========================================");
            System.out.println("1. View All Customers");
            System.out.println("2. View All Bills");
            System.out.println("3. Generate Report");
            System.out.println("4. Logout");
            System.out.print("Enter your choice (1-4): ");

            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                	 List<CustomerRegistration> customers = adminService.getAllCustomers();
                     adminService.displayCustomers(customers);
                    break;
                case 2:
                	List<Bill> bills = adminService.getAllBills();
                    adminService.displayBills(bills);
                    break;
                case 3:
                    adminService.generateReport();
                    break;
                    
                case 4:
                    System.out.println("Logging out...");
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }


    private static void handleCustomerLogin(Scanner scanner) {
        System.out.println("\n==========================================");
        System.out.println("             Customer Login");
        System.out.println("==========================================");

        System.out.print("Enter Customer Number: ");
        String customerNumber = scanner.nextLine();

        System.out.print("Enter Password: ");
        String password = scanner.nextLine();

        // Validate customer and log them in
        CustomerRegistration customer = customerService.validateCustomer(customerNumber, password);
        if (customer != null) {
            loggedInCustomer = customer; // Store the logged-in customer
            System.out.println("Login Successful! Welcome, " + customer.getFirstName() + ".");
            displayCustomerDashboard(scanner, customerNumber);
        } else {
            System.out.println("Invalid Customer Number or Password. Please try again.");
        }
    }
       
    private static void handleCustomerRegistration(Scanner scanner, CustomerService customerService) {
        System.out.println("\n==========================================");
        System.out.println("        New Customer Registration");
        System.out.println("==========================================");
        
        CustomerRegistration registration = new CustomerRegistration();

        System.out.print("Enter First Name: ");
        registration.setFirstName(scanner.nextLine());
        
        System.out.print("Enter Parent's Name: ");
        registration.setMiddleName(scanner.nextLine());
        
        System.out.print("Enter Surname: ");
        registration.setSurname(scanner.nextLine());
        
        System.out.println("Enter Address Details:");       
        System.out.print("  At Post: ");
        registration.setAtPost(scanner.nextLine());
        
        System.out.print("  Plot No: ");
        registration.setPlotNo(scanner.nextInt());
        
        scanner.nextLine(); //newline
        System.out.print("  Taluka: ");
        registration.setTaluka(scanner.nextLine());
        
        System.out.print("  District: ");
        registration.setDistrict(scanner.nextLine());
        
        System.out.print("  Pincode: ");
        registration.setPincode(scanner.nextInt());
        
        scanner.nextLine(); //newline
        System.out.print("  State: ");
        registration.setState(scanner.nextLine());
        
        System.out.print("  Area: ");
        registration.setArea(scanner.nextLine());

        System.out.print("  Enter Mobile Number: ");
        registration.setCustId(scanner.nextInt());
        
        System.out.print("  Enter Electricity Number: ");
        registration.setElectricityNo(scanner.nextLine());
        
        scanner.nextLine(); //newline
        System.out.print("  Enter Initial Meter Reading: ");
        registration.setInitialMeterReading(scanner.nextLine());
        
        // Set Password
        System.out.print("Create Password: ");
       String password = scanner.nextLine();
        registration.setPassword(password);

        System.out.print("Confirm Password: ");
        String confirmPassword = scanner.nextLine();

        if (!password.equals(confirmPassword)) {
            System.out.println("Error: Passwords do not match. Please try again.");
            return;
        }

        System.out.println("\nProcessing Registration...");

        boolean isSuccess = customerService.registerCustomer(registration);
        if (isSuccess) {
            System.out.println("Registration Successful! Your Customer Number is " + registration.getCustomerNumber());
            System.out.println("Please login to manage your account.");
        } else {
            System.out.println("Registration Failed. Please try again.");
        }
        
    }              
    private static void displayCustomerDashboard(Scanner scanner,String customerNumber) {
        if (loggedInCustomer == null) {
            System.out.println("No customer is currently logged in.");
            return;
        }
        
            while (true) {
                System.out.println("\n==========================================");
                System.out.println("             Customer Dashboard");
                System.out.println("==========================================");
                System.out.println("1. View Electricity Usage");
                System.out.println("2. Pay Bill");
                System.out.println("3. View Payment History");
                System.out.println("4. Update Account Details");
                System.out.println("5. Logout");
                System.out.print("Enter your choice (1-5): ");

                int choice = scanner.nextInt();
                scanner.nextLine(); // Consume newline

                switch (choice) {
                case 1:
                	 viewElectricityUsage();
                case 2:
                      handlePayBill(scanner, customerNumber);
                    break;
                case 3:
                     handleViewPaymentHistory();
                    break;
                case 4:
                    //customerService.getCustomerDetails(customerNumber);
                    break;
                case 5:
                    System.out.println("Logging out...");
                    return;

                    default:
                        System.out.println("Invalid choice. Please try again.");
                }
            }
        }
        
    private static void viewElectricityUsage() {
        if (loggedInCustomer == null) {
            System.out.println("No customer is currently logged in.");
            return;
        }

        List<ElectricityUsage> usageList = electricityUsageService.getUsage(loggedInCustomer.getCustomerNumber());

        if (usageList.isEmpty()) {
                System.out.println("No electricity usage records found for the given customer.");
            } else {
                System.out.println("==========================================");
                System.out.println("         Electricity Usage Summary        ");
                System.out.println("==========================================");
                System.out.printf("%-12s %-18s\n", "Date", "Units Used");
                System.out.println("------------------------------------------");
                
                for (ElectricityUsage usage : usageList) {
                    System.out.printf("%-12s %-18.2f\n", usage.getUsageDate(), usage.getUnitsUsed());
                }
                System.out.println("==========================================");
            }
            System.out.println("\nPress Enter to return to the dashboard.");
            new Scanner(System.in).nextLine(); // Pause before showing the dashboard again.
        }
       

    private static void handlePayBill(Scanner scanner, String customerNumber) {
        if (customerNumber == null || customerNumber.isEmpty()) {
            System.out.println("Error: Customer number is not available. Cannot process payment.");
            return;
        }
            System.out.println("\n==========================================");
            System.out.println("                 Pay Bill");
            System.out.println("==========================================");
//            
//            List<Bill> unpaidBills = billService.getUnpaidBills(customerNumber);
//            billService.displayBills(unpaidBills);
//           
            System.out.print("Enter Payment Amount: ");
            double amount = scanner.nextDouble();
            scanner.nextLine(); // Consume newline

            System.out.println("Select Payment Method:");
            System.out.println("1. Cash");
            System.out.println("2. Card");
            System.out.println("3. Online");
            System.out.print("Enter your choice: ");
            int methodChoice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            String method;
            switch (methodChoice) {
                case 1:
                    method = "Cash";
                    break;
                case 2:
                    method = "Card";
                    break;
                case 3:
                    method = "Online";
                    break;
                default:
                    method = null;
                    break;
            }


            if (method != null && paymentHistoryService.processPayment(customerNumber, amount, method)) {
                System.out.printf("Payment Successful! ₹%.2f has been deducted.%n", amount);
            } else {
                System.out.println("Payment Failed. Please try again.");
            }

            System.out.println("Press Enter to return to the dashboard.");
            scanner.nextLine();
        }

    private static void handleViewPaymentHistory() {
        if (loggedInCustomer == null) {
            System.out.println("Error: No customer is logged in. Cannot view payment history.");
            return;
        }

        System.out.println("\n==========================================");
        System.out.println("          Payment History");
        System.out.println("==========================================");

        // Fetch payment history using the logged-in customer's customerNumber
        List<PaymentHistory> paymentHistoryList = paymentHistoryService.getHistory(loggedInCustomer.getCustomerNumber());

        // Check if there is any payment history
        if (paymentHistoryList == null || paymentHistoryList.isEmpty()) {
            System.out.println("No payment history found for your account.");
        } else {
            // Display payment history in a formatted table
            System.out.printf("%-15s %-15s %-20s%n", "Payment Date", "Amount Paid", "Payment Method");
            System.out.println("------------------------------------------------------------");
            for (PaymentHistory payment : paymentHistoryList) {
                System.out.printf(
                    "%-15s %-15.2f %-20s%n",
                    payment.getPaymentDate(),
                    payment.getAmountPaid(),
                    payment.getPaymentMethod()
                );
            }
        }

        System.out.println("\nPress Enter to return to the dashboard.");
        new Scanner(System.in).nextLine();
    }
    
        private static void handleUpdateAccountDetails(Scanner scanner, String customerNumber) {
        	
}
}
  

