package electricity_24_7.com.OnlineElectricitySystem.customexceptions;

/**
 * This class contains custom exceptions for the Online Electricity System.
 */

public class CustomExceptions {

    // Exception for when a customer is not logged in but attempts to perform actions requiring authentication
    public static class CustomerNotLoggedInException extends RuntimeException {
        public CustomerNotLoggedInException(String message) {
            super(message);
        }
    }

    // Exception for invalid customer number data
    public static class InvalidCustomerNumberException extends RuntimeException {
        public InvalidCustomerNumberException(String message) {
            super(message);
        }
    }

    // Exception for when no electricity usage records are found for a customer
    public static class ElectricityUsageNotFoundException extends RuntimeException {
        public ElectricityUsageNotFoundException(String message) {
            super(message);
        }
    }

    // Exception for when a bill payment fails
    public static class BillPaymentException extends RuntimeException {
        public BillPaymentException(String message) {
            super(message);
        }
    }

    // Exception for when payment history is not available
    public static class PaymentHistoryNotFoundException extends RuntimeException {
        public PaymentHistoryNotFoundException(String message) {
            super(message);
        }
    }

    // Exception for when a customer record is not found during update or retrieval
    public static class CustomerNotFoundException extends RuntimeException {
        public CustomerNotFoundException(String message) {
            super(message);
        }
    }

    // General exception for invalid input
    public static class InvalidInputException extends RuntimeException {
        public InvalidInputException(String message) {
            super(message);
        }
    }
}
