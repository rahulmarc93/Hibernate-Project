package electricity_24_7.com.OnlineElectricitySystem.dao;

public interface AdminDao {
    boolean validateAdminLogin(String username, String password);
}
