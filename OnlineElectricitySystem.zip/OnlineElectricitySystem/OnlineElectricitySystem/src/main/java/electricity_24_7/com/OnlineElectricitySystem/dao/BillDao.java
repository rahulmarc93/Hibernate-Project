package electricity_24_7.com.OnlineElectricitySystem.dao;

import electricity_24_7.com.OnlineElectricitySystem.entity.Bill;

import java.util.List;

public interface BillDao {

    List<Bill> getOutstandingBills(String customerNumber);

    void saveBill(Bill bill);

    List<Bill> getBillsByCustomer(int customerId);

    List<Bill> getBillsByMeter(Long meterId);

    List<Bill> getAllBills();
}
