package electricity_24_7.com.OnlineElectricitySystem.dao;

import java.util.List;

//import com.mysql.cj.Session;
import org.hibernate.Session;
import org.hibernate.Transaction;

import electricity_24_7.com.OnlineElectricitySystem.entity.Bill;
import electricity_24_7.com.OnlineElectricitySystem.util.HibernateUtil;
//import jakarta.transaction.Transaction;

public class BillDao {
      
	 public boolean saveBill(Bill bill) {
	        Transaction transaction = null;
	        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
	            transaction = session.beginTransaction();
	            session.saveOrUpdate(bill);
	            transaction.commit();
	            return true;
	        } catch (Exception e) {
	            if (transaction != null) transaction.rollback();
	            e.printStackTrace();
	            return false;
	        }
	    }

	    public List<Bill> getBillsByCustomer(int customerId) {
	        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
	            return session.createQuery("FROM Bill WHERE customer.custId = :customerId", Bill.class)
	                    .setParameter("customerId", customerId)
	                    .list();
	        }
	    }

	    public List<Bill> getBillsByMeter(Long meterId) {
	        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
	            return session.createQuery("FROM Bill WHERE meter.id = :meterId", Bill.class)
	                    .setParameter("meterId", meterId)
	                    .list();
	        }
	    }

	    // Fetch all bills from the database
	    public List<Bill> getAllBills() {
	        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
	            return session.createQuery("FROM Bill", Bill.class).list();
	        }
	    }
	}

