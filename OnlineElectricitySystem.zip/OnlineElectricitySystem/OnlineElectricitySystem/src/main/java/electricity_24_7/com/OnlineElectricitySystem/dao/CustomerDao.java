package electricity_24_7.com.OnlineElectricitySystem.dao;

import electricity_24_7.com.OnlineElectricitySystem.entity.CustomerRegistration;

import java.util.List;

public interface CustomerDao {

    boolean saveCustomerRegistration(CustomerRegistration registration);

    CustomerRegistration getCustomerByNumber(String customerNumber);

    List<CustomerRegistration> getAllCustomers();

    boolean updateCustomer(CustomerRegistration customer);

    CustomerRegistration getCustomerByCustomerNumber(String customerNumber);

    CustomerRegistration findByCustomerNumber(String customerNumber);
}