package electricity_24_7.com.OnlineElectricitySystem.dao;

import electricity_24_7.com.OnlineElectricitySystem.entity.CustomerRegistration;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;
import electricity_24_7.com.OnlineElectricitySystem.util.HibernateUtil;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.TypedQuery;

public class CustomerDao {

    public boolean saveCustomerRegistration(CustomerRegistration registration) {
        Transaction transaction = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            transaction = session.beginTransaction();
            session.save(registration);
            transaction.commit();
            return true;
        } 
//        catch (Exception e) {
//            if (transaction != null) {
//                transaction.rollback();
//            }
            //e.printStackTrace();
          //  return false;
        }
   // }
    
    
    public CustomerRegistration getCustomerByNumber(String customerNumber) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            return session.createQuery("FROM CustomerRegistration WHERE customerNumber = :customerNumber", CustomerRegistration.class)
                          .setParameter("customerNumber", customerNumber)
                          .uniqueResult();
        } 
//        catch (Exception e) {
//            e.printStackTrace();
//            return null;
//      	  }
    }
    
    // Fetch all customers from the database
    public List<CustomerRegistration> getAllCustomers() {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            return session.createQuery("FROM CustomerRegistration", CustomerRegistration.class).list();
        }
    }
    // Fetch a customer by their customer number
    public CustomerRegistration getCustomerByCustomerNumber(String customerNumber) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            return session.createQuery("FROM CustomerRegistration WHERE customerNumber = :customerNumber", CustomerRegistration.class)
                          .setParameter("customerNumber", customerNumber)
                          .uniqueResult();
        }
    }

    // Update customer details
   

    public boolean updateCustomerDetails(CustomerRegistration updatedCustomer) {
        Transaction transaction = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            transaction = session.beginTransaction();
            session.update(updatedCustomer);
            transaction.commit();
            return true;
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            e.printStackTrace();
            return false;
        }
    }
   
}



