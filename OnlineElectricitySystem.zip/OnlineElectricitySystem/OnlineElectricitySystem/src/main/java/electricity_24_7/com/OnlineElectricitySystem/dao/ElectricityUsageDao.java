package electricity_24_7.com.OnlineElectricitySystem.dao;

import java.util.List;
import electricity_24_7.com.OnlineElectricitySystem.entity.ElectricityUsage;

public interface ElectricityUsageDao {

    List<ElectricityUsage> getUsageByCustomer(String customerNumber);

    List<ElectricityUsage> getUsageByCustomerNumber(String customerNumber);

    void saveElectricityUsage(ElectricityUsage usage);

    List<ElectricityUsage> getElectricityUsageByCustomerNumber(String customerNumber);
}
