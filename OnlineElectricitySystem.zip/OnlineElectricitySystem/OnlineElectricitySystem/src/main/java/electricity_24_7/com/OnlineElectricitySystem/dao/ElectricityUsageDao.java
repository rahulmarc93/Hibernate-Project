package electricity_24_7.com.OnlineElectricitySystem.dao;

import java.util.List;

import org.hibernate.Session;

import electricity_24_7.com.OnlineElectricitySystem.entity.ElectricityUsage;
import electricity_24_7.com.OnlineElectricitySystem.util.HibernateUtil;

public class ElectricityUsageDao {
	
	public List<ElectricityUsage> getUsageByCustomer(String customerNumber) {
		 try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            return session.createQuery("FROM ElectricityUsage WHERE customerNumber = :customerNumber", ElectricityUsage.class)
                          .setParameter("customerNumber", customerNumber)
                          .list();
        }
    }
	
	 // Fetch electricity usage by customer number
    public List<ElectricityUsage> getUsageByCustomerNumber(String customerNumber) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            return session.createQuery(
                    "FROM ElectricityUsage WHERE customer.customerNumber = :customerNumber", 
                    ElectricityUsage.class)
                          .setParameter("customerNumber", customerNumber)
                          .list();
        }
    }

}
