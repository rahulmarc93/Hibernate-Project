package electricity_24_7.com.OnlineElectricitySystem.dao;

import electricity_24_7.com.OnlineElectricitySystem.entity.Meter;
import electricity_24_7.com.OnlineElectricitySystem.entity.CustomerRegistration;

public interface MeterDao {

    Meter getMeterByNumber(String meterNumber);

    boolean saveMeter(Meter meter);

    Meter findByMeterNumber(String meterNumber);

    String addMeterInfo(String customerNumber, String meterNumber, String installationDate, String status);
}
