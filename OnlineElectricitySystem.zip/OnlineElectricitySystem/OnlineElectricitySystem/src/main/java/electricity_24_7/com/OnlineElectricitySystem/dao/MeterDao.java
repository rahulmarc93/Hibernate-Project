package electricity_24_7.com.OnlineElectricitySystem.dao;

import org.hibernate.Session;
import org.hibernate.Transaction;

import electricity_24_7.com.OnlineElectricitySystem.entity.Meter;
import electricity_24_7.com.OnlineElectricitySystem.util.HibernateUtil;

public class MeterDao {

    public boolean saveMeter(Meter meter) {
        Transaction transaction = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            transaction = session.beginTransaction();
            session.save(meter);
            transaction.commit();
            return true;
        } catch (Exception e) {
            if (transaction != null) transaction.rollback();
            e.printStackTrace();
            return false;
        }
    }
}

