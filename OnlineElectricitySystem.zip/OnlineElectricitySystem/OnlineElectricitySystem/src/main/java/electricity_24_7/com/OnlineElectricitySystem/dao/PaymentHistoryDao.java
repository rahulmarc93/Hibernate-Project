package electricity_24_7.com.OnlineElectricitySystem.dao;

import java.util.List;
import electricity_24_7.com.OnlineElectricitySystem.entity.Bill;
import electricity_24_7.com.OnlineElectricitySystem.entity.PaymentHistory;

public interface PaymentHistoryDao {

    void savePaymentHistory(Bill bill, double amountPaid, String paymentMethod);

    List<PaymentHistory> getPaymentHistoryByCustomer(String customerNumber);
}
