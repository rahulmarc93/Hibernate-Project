package electricity_24_7.com.OnlineElectricitySystem.dao;

import java.util.List;

import org.hibernate.Session;

import electricity_24_7.com.OnlineElectricitySystem.entity.PaymentHistory;
import electricity_24_7.com.OnlineElectricitySystem.util.HibernateUtil;
import jakarta.transaction.Transaction;

public class PaymentHistoryDao {
	
	public boolean savePayment(PaymentHistory payment) {
        org.hibernate.Transaction transaction = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            transaction = session.beginTransaction();
            session.save(payment);
            transaction.commit();
            return true;
        } catch (Exception e) {
            if (transaction != null) transaction.rollback();
            e.printStackTrace();
            return false;
        }
    }

    public List<PaymentHistory> getPaymentHistoryByCustomer(String customerNumber) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            return session.createQuery("FROM PaymentHistory WHERE customerNumber = :customerNumber", PaymentHistory.class)
                          .setParameter("customerNumber", customerNumber)
                          .list();
        }
    }

}
