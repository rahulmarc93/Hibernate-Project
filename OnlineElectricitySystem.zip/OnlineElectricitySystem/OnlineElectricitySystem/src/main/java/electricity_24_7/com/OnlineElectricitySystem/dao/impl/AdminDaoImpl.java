package electricity_24_7.com.OnlineElectricitySystem.dao.impl;

import org.hibernate.Session;
import org.hibernate.query.Query;

import electricity_24_7.com.OnlineElectricitySystem.dao.AdminDao;
import electricity_24_7.com.OnlineElectricitySystem.entity.AdminLogin;
import electricity_24_7.com.OnlineElectricitySystem.util.HibernateUtil;

public class AdminDaoImpl implements AdminDao {

    @Override
    public boolean validateAdminLogin(String username, String password) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        try {
            String hql = "FROM Admin WHERE username = :username AND password = :password";
            Query<AdminLogin> query = session.createQuery(hql, AdminLogin.class);
            query.setParameter("username", username);
            query.setParameter("password", password);

            AdminLogin admin = query.uniqueResult();
            return admin != null; // Returns true if admin exists
        } 
        catch (Exception e) {
            // e.printStackTrace();
            return false;
        } 
        finally {
            session.close();
        }
    }
}
