package electricity_24_7.com.OnlineElectricitySystem.dao.impl;

import electricity_24_7.com.OnlineElectricitySystem.dao.BillDao;
import electricity_24_7.com.OnlineElectricitySystem.entity.Bill;
import electricity_24_7.com.OnlineElectricitySystem.util.HibernateUtil;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import java.util.ArrayList;
import java.util.List;

public class BillDaoImpl implements BillDao {

    @Override
    public List<Bill> getOutstandingBills(String customerNumber) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            Query<Bill> query = session.createQuery(
                "SELECT b FROM Bill b WHERE b.customer.customerNumber = :customerNumber AND b.paymentStatus = 'Unpaid'",
                Bill.class
            );
            query.setParameter("customerNumber", customerNumber);
            return query.list();
        } catch (Exception e) {
            e.printStackTrace();
            return new ArrayList<>();
        }
    }

    @Override
    public void saveBill(Bill bill) {
        Transaction transaction = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            transaction = session.beginTransaction();
            session.save(bill);
            transaction.commit();
            System.out.println("Bill added successfully!");
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            e.printStackTrace();
        }
    }

    @Override
    public List<Bill> getBillsByCustomer(int customerId) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            return session.createQuery("FROM Bill WHERE customer.custId = :customerId", Bill.class)
                    .setParameter("customerId", customerId)
                    .list();
        }
    }

    @Override
    public List<Bill> getBillsByMeter(Long meterId) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            return session.createQuery("FROM Bill WHERE meter.id = :meterId", Bill.class)
                    .setParameter("meterId", meterId)
                    .list();
        }
    }

    @Override
    public List<Bill> getAllBills() {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            return session.createQuery("FROM Bill", Bill.class).list();
        }
    }
}
