package electricity_24_7.com.OnlineElectricitySystem.dao.impl;

import electricity_24_7.com.OnlineElectricitySystem.dao.CustomerDao;
import electricity_24_7.com.OnlineElectricitySystem.entity.CustomerRegistration;
import electricity_24_7.com.OnlineElectricitySystem.util.HibernateUtil;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import java.util.List;

public class CustomerDaoImpl implements CustomerDao {

    @Override
    public boolean saveCustomerRegistration(CustomerRegistration registration) {
        Transaction transaction = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            transaction = session.beginTransaction();
            session.save(registration);
            transaction.commit();
            return true;
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public CustomerRegistration getCustomerByNumber(String customerNumber) {
        Transaction transaction = null;
        CustomerRegistration customer = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            transaction = session.beginTransaction();
            customer = session.createQuery("FROM CustomerRegistration WHERE customerNumber = :customerNumber", CustomerRegistration.class)
                              .setParameter("customerNumber", customerNumber)
                              .uniqueResult();
            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            e.printStackTrace();
        }
        return customer;
    }

    @Override
    public List<CustomerRegistration> getAllCustomers() {
        List<CustomerRegistration> customers = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            String hql = "FROM CustomerRegistration";
            Query<CustomerRegistration> query = session.createQuery(hql, CustomerRegistration.class);
            customers = query.list();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return customers;
    }

    @Override
    public boolean updateCustomer(CustomerRegistration customer) {
        Transaction transaction = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            transaction = session.beginTransaction();
            session.update(customer);
            transaction.commit();
            return true;
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public CustomerRegistration getCustomerByCustomerNumber(String customerNumber) {
        Transaction transaction = null;
        CustomerRegistration customer = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            transaction = session.beginTransaction();
            Query<CustomerRegistration> query = session.createQuery("FROM CustomerRegistration WHERE customerNumber = :customerNumber", CustomerRegistration.class);
            query.setParameter("customerNumber", customerNumber);
            customer = query.uniqueResult();
            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            e.printStackTrace();
        }
        return customer;
    }

    @Override
    public CustomerRegistration findByCustomerNumber(String customerNumber) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            return session.createQuery("FROM CustomerRegistration WHERE customer_number = :customerNumber", CustomerRegistration.class)
                    .setParameter("customerNumber", customerNumber)
                    .uniqueResult();
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}
