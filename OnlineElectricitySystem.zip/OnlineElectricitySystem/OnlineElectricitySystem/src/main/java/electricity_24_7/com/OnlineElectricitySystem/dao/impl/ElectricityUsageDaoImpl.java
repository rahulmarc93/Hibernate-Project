package electricity_24_7.com.OnlineElectricitySystem.dao.impl;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import electricity_24_7.com.OnlineElectricitySystem.dao.ElectricityUsageDao;
import electricity_24_7.com.OnlineElectricitySystem.entity.ElectricityUsage;
import electricity_24_7.com.OnlineElectricitySystem.util.HibernateUtil;

public class ElectricityUsageDaoImpl implements ElectricityUsageDao {

    @Override
    public List<ElectricityUsage> getUsageByCustomer(String customerNumber) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            return session.createQuery("FROM ElectricityUsage WHERE customerNumber = :customerNumber", ElectricityUsage.class)
                          .setParameter("customerNumber", customerNumber)
                          .list();
        }
    }

    @Override
    public List<ElectricityUsage> getUsageByCustomerNumber(String customerNumber) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            return session.createQuery(
                    "FROM ElectricityUsage WHERE customer.customerNumber = :customerNumber", 
                    ElectricityUsage.class)
                          .setParameter("customerNumber", customerNumber)
                          .list();
        }
    }

    @Override
    public void saveElectricityUsage(ElectricityUsage usage) {
        Transaction transaction = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            transaction = session.beginTransaction();

            // Save the electricity usage record
            session.save(usage);

            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            // e.printStackTrace();
        }
    }

    @Override
    public List<ElectricityUsage> getElectricityUsageByCustomerNumber(String customerNumber) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            // Fetch usage records by customerNumber
            Query<ElectricityUsage> query = session.createQuery(
                "SELECT e FROM ElectricityUsage e WHERE e.customer.customerNumber = :customerNumber ORDER BY e.usageDate DESC",
                ElectricityUsage.class
            );
            query.setParameter("customerNumber", customerNumber);

            return query.list();
        } catch (Exception e) {
            // e.printStackTrace();
            return new ArrayList<>();
        }
    }
}
