package electricity_24_7.com.OnlineElectricitySystem.entity;

import java.util.List;

import jakarta.persistence.*;

@Entity
@Table(name = "customer")
public class CustomerRegistration {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "custId")
    private int custId;

    @Column(name = "firstName")
    private String firstName;

    @Column(name = "middleName")
    private String middleName;

    @Column(name = "surname")
    private String surname;

    @Column(name = "address")
    private String address;

    @Column(name = "area")
    private String area;

    @Column(name = "atPost")
    private String atPost;
    
    @Column(name = "taluka")
    private String taluka;

    @Column(name = "district")
    private String district;

    @Column(name = "state")
    private String state;

    @Column(name = "pincode")
    private int pincode;

    @Column(name = "plotNo")
    private int plotNo;

    @Column(name = "electricityNo")
    private String electricityNo;

    @Column(name = "initialMeterReading")
    private String initialMeterReading;
    
    @Column(name = "password")
    private String password;
    
    @Column(name = "confirmPassword")
    private String confirmPassword;
    
    @Column(name = "customer_number", nullable = false, unique = true)
    private String customerNumber;

    // Relationships
    @OneToMany(mappedBy = "customer", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<PaymentHistory> paymentHistoryList;

    @OneToMany(mappedBy = "customer", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<ElectricityUsage> electricityUsageList;

    @OneToOne(mappedBy = "customer", cascade = CascadeType.ALL, orphanRemoval = true)
    private Meter meter;

    @OneToMany(mappedBy = "customer", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Bill> bills;
    
	public int getCustId() {
		return custId;
	}

	public void setCustId(int custId) {
		this.custId = custId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getMiddleName() {
		return middleName;
	}

	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	public String getSurname() {
		return surname;
	}

	public void setSurname(String surname) {
		this.surname = surname;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getArea() {
		return area;
	}

	public void setArea(String area) {
		this.area = area;
	}

	public String getAtPost() {
		return atPost;
	}

	public void setAtPost(String atPost) {
		this.atPost = atPost;
	}

	public String getTaluka() {
		return taluka;
	}

	public void setTaluka(String taluka) {
		this.taluka = taluka;
	}

	public String getDistrict() {
		return district;
	}

	public void setDistrict(String district) {
		this.district = district;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public int getPincode() {
		return pincode;
	}

	public void setPincode(int pincode) {
		this.pincode = pincode;
	}

	public int getPlotNo() {
		return plotNo;
	}

	public void setPlotNo(int plotNo) {
		this.plotNo = plotNo;
	}

	public String getElectricityNo() {
		return electricityNo;
	}

	public void setElectricityNo(String electricityNo) {
		this.electricityNo = electricityNo;
	}

	public String getInitialMeterReading() {
		return initialMeterReading;
	}

	public void setInitialMeterReading(String initialMeterReading) {
		this.initialMeterReading = initialMeterReading;
	}
	
	public String getPassword() {
	    return password;
	}

	public void setPassword(String password) {
	    this.password = password;
	}
	
	public String getconfirmPassword() {
	    return confirmPassword;
	}

	public void setconfirmPassword(String confirmPassword) {
	    this.confirmPassword = confirmPassword;
	}
	
		
	public String getCustomerNumber() {
        return customerNumber;
    }

    public void setCustomerNumber(String customerNumber) {
        this.customerNumber = customerNumber;
    }
    
    public List<PaymentHistory> getpaymentHistoryList() {
        return paymentHistoryList;
    }

    public void setpaymentHistoryList(List<PaymentHistory> paymentHistoryList) {
        this.paymentHistoryList = paymentHistoryList;
    }

    public List<ElectricityUsage> getElectricityUsagesList() {
        return electricityUsageList;
    }

    public void setElectricityUsagesList(List<ElectricityUsage> electricityUsageList) {
        this.electricityUsageList = electricityUsageList;
    }
    
    public Meter getmeter() {
        return meter;
    }

    public void setCustomerNumber(Meter meter) {
        this.meter = meter;
    }
    
    public List<Bill> getBill() {
        return bills;
    }

    public void setBill(List<Bill> bills) {
        this.bills = bills;
    }
    
    
}
