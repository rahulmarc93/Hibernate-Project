package electricity_24_7.com.OnlineElectricitySystem.entity;

import java.time.LocalDate;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "electricity_usage")

public class ElectricityUsage {
	
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "usage_date", nullable = false)
    private LocalDate usageDate;

    @Column(name = "units_used", nullable = false)
    private double unitsUsed;

    @ManyToOne
    @JoinColumn(name = "customer_number", nullable = false)
    private CustomerRegistration customer;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public LocalDate getUsageDate() {
		return usageDate;
	}

	public void setUsageDate(LocalDate usageDate) {
		this.usageDate = usageDate;
	}

	public double getUnitsUsed() {
		return unitsUsed;
	}

	public void setUnitsUsed(double unitsUsed) {
		this.unitsUsed = unitsUsed;
	}

	public CustomerRegistration getCustomer() {
		return customer;
	}

	public void setCustomer(CustomerRegistration customer) {
		this.customer = customer;
	}
    
    
}

//	 @Id
//	    @GeneratedValue(strategy = GenerationType.IDENTITY)
//	    private Long id;
//
//	    @Column(name = "customer_number", nullable = false)
//	    private String customerNumber;
//
//	    @Column(name = "month", nullable = false)
//	    private String month;
//
//	    @Column(name = "units_consumed", nullable = false)
//	    private int unitsConsumed;
//
//	    @Column(name = "amount_due", nullable = false)
//	    private double amountDue;
//
//	    @Column(name = "billing_date", nullable = false)
//	    private LocalDate billingDate;
//
//	    // Getters and Setters
//	    public Long getId() {
//	        return id;
//	    }
//
//	    public void setId(Long id) {
//	        this.id = id;
//	    }
//
//	    public String getCustomerNumber() {
//	        return customerNumber;
//	    }
//
//	    public void setCustomerNumber(String customerNumber) {
//	        this.customerNumber = customerNumber;
//	    }
//
//	    public String getMonth() {
//	        return month;
//	    }
//
//	    public void setMonth(String month) {
//	        this.month = month;
//	    }
//
//	    public int getUnitsConsumed() {
//	        return unitsConsumed;
//	    }
//
//	    public void setUnitsConsumed(int unitsConsumed) {
//	        this.unitsConsumed = unitsConsumed;
//	    }
//
//	    public double getAmountDue() {
//	        return amountDue;
//	    }
//
//	    public void setAmountDue(double amountDue) {
//	        this.amountDue = amountDue;
//	    }
//
//	    public LocalDate getBillingDate() {
//	        return billingDate;
//	    }
//
//	    public void setBillingDate(LocalDate billingDate) {
//	        this.billingDate = billingDate;
//	    }
//	}
//
