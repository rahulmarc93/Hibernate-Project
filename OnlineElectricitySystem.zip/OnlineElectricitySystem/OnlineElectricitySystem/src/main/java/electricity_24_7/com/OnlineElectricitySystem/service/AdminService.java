package electricity_24_7.com.OnlineElectricitySystem.service;

import java.util.List;

import electricity_24_7.com.OnlineElectricitySystem.dao.AdminDao;
import electricity_24_7.com.OnlineElectricitySystem.dao.BillDao;
import electricity_24_7.com.OnlineElectricitySystem.dao.CustomerDao;
import electricity_24_7.com.OnlineElectricitySystem.entity.Bill;
import electricity_24_7.com.OnlineElectricitySystem.entity.CustomerRegistration;

public class AdminService {
	
    private AdminDao adminDAO = new AdminDao();
    private CustomerDao customerDao = new CustomerDao();
    private BillDao billDao = new BillDao();
	
    
 // Hardcoded Admin credentials
    private static final String username = "admin";
    private static final String password = "admin123";

    
 // Validate Admin Credentials
    public static boolean validateAdmin(String username, String password) {
        return username.equals(username) && password.equals(password);
    }
    
    // Fetch All Customers
    public List<CustomerRegistration> getAllCustomers() {
        return customerDao.getAllCustomers();
    }
 // Display Customers in Tabular Format
    public void displayCustomers(List<CustomerRegistration> customers) {
        System.out.println("\n==========================================");
        System.out.println("         Customer Information");
        System.out.println("==========================================");
        System.out.printf("%-10s %-15s %-20s %-15s%n", "CustID", "Full Name", "Electricity No", "Mobile No");
        System.out.println("------------------------------------------");

        for (CustomerRegistration customer : customers) {
            String fullName = customer.getFirstName() + " " + customer.getMiddleName() + " " + customer.getSurname();
            System.out.printf("%-10d %-15s %-20s %-15s%n",
                    customer.getCustId(),
                    fullName,
                    customer.getElectricityNo(),
                    customer.getCustomerNumber());
        }

        System.out.println("------------------------------------------");
    }
 // Fetch all bills
    public List<Bill> getAllBills() {
        return billDao.getAllBills();
    }
 // Display bills in tabular format
    public void displayBills(List<Bill> bills) {
        System.out.println("\n==================================================================================");
        System.out.println("                                Bill Information");
        System.out.println("===================================================================================");
        System.out.printf("%-10s %-15s %-15s %-15s %-15s %-10s%n", 
                "Bill ID", "Customer Name", "Meter ID", "Billing Date", "Amount", "Payment Status");
        System.out.println("------------------------------------------------------------------------------------------");

        for (Bill bill : bills) {
            System.out.printf("%-10d %-15s %-15s %-15s ₹%-10.2f %-15s%n",
                    bill.getBillId(),
                    bill.getCustomer().getFirstName() + " " + bill.getCustomer().getFirstName(),
                    bill.getMeter().getMeterNumber(),
                    bill.getBillingDate(),
                    bill.getAmount(),
                    bill.getPaymentStatus());
        }

        System.out.println("------------------------------------------------------------------------------------------");
    }
 // Generate a revenue report
    public void generateReport() {
        List<Bill> bills = getAllBills();
        double totalRevenue = bills.stream()
                                   .mapToDouble(Bill::getAmount)
                                   .sum();

        long unpaidBills = bills.stream()
                                 .filter(bill -> !bill.getPaymentStatus().equalsIgnoreCase("Paid"))
                                 .count();

        System.out.println("\n==========================================");
        System.out.println("              Revenue Report");
        System.out.println("==========================================");
        System.out.println("Total Bills Generated: " + bills.size());
        System.out.println("Total Revenue: ₹" + totalRevenue);
        System.out.println("Unpaid Bills: " + unpaidBills);
        System.out.println("==========================================");
    }
}

