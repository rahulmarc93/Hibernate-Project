package electricity_24_7.com.OnlineElectricitySystem.service;

import electricity_24_7.com.OnlineElectricitySystem.entity.Bill;
import electricity_24_7.com.OnlineElectricitySystem.entity.CustomerRegistration;
import electricity_24_7.com.OnlineElectricitySystem.entity.Meter;
import electricity_24_7.com.OnlineElectricitySystem.service.impl.AdminServiceImpl;

import java.util.List;

public interface AdminService {
    boolean validateAdmin(String username, String password);
    void addBill();
    CustomerRegistration getCustomerByNumber(String customerNumber);
    Meter getMeterByNumber(String meterNumber);
    List<CustomerRegistration> getAllCustomers();
    void displayCustomers(List<CustomerRegistration> customers);
    List<Bill> getAllBills();
    void displayBills(List<Bill> bills);
    void generateReport();
}
