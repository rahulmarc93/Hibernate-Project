package electricity_24_7.com.OnlineElectricitySystem.service;

import java.util.List;

import electricity_24_7.com.OnlineElectricitySystem.entity.Bill;

public interface BillService {

    List<Bill> getUnpaidBills(String customerNumber);

    void payBill(int billId);
}
