package electricity_24_7.com.OnlineElectricitySystem.service;

import java.time.LocalDate;
import java.util.List;

import electricity_24_7.com.OnlineElectricitySystem.dao.BillDao;
import electricity_24_7.com.OnlineElectricitySystem.entity.Bill;
import electricity_24_7.com.OnlineElectricitySystem.entity.CustomerRegistration;
import electricity_24_7.com.OnlineElectricitySystem.entity.Meter;

public class BillService {

    private final BillDao billDao = new BillDao();

    public boolean generateBill(CustomerRegistration customer, Meter meter, double amount) {
        Bill bill = new Bill();
        bill.setBillingDate(LocalDate.now());
        bill.setAmount(amount);
        bill.setPaymentStatus("Pending");
        bill.setCustomer(customer);
        bill.setMeter(meter);

        return billDao.saveBill(bill);
    }

    public List<Bill> getCustomerBills(int customerId) {
        return billDao.getBillsByCustomer(customerId);
    }

    public List<Bill> getMeterBills(Long meterId) {
        return billDao.getBillsByMeter(meterId);
    }

    public boolean updatePaymentStatus(Long billId, String status) {
        List<Bill> bills = billDao.getBillsByMeter(billId);
        if (bills.isEmpty()) return false;

        Bill bill = bills.get(0);
        bill.setPaymentStatus(status);
        return billDao.saveBill(bill);
    }
}
