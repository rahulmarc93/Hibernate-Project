package electricity_24_7.com.OnlineElectricitySystem.service;

import electricity_24_7.com.OnlineElectricitySystem.entity.CustomerRegistration;

public interface CustomerService {

    boolean registerCustomer(CustomerRegistration registration);

    CustomerRegistration validateCustomer(String customerNumber, String password);

    CustomerRegistration getCustomerDetails(String customerNumber);
}
