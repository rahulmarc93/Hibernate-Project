package electricity_24_7.com.OnlineElectricitySystem.service;

import electricity_24_7.com.OnlineElectricitySystem.dao.CustomerDao;
import electricity_24_7.com.OnlineElectricitySystem.entity.CustomerRegistration;
import jakarta.transaction.Transactional;

public class CustomerService {

    private CustomerDao customerDAO = new CustomerDao();
    
    public boolean registerCustomer(CustomerRegistration registration) {
        // Generate Customer Number: Prefix "CUST" + Auto-increment ID
        registration.setCustomerNumber("CUST" + System.currentTimeMillis() % 100000);
        return customerDAO.saveCustomerRegistration(registration);
    }
    
    public CustomerRegistration validateCustomer(String customerNumber, String password) {
        CustomerRegistration customer = customerDAO.getCustomerByNumber(customerNumber);
        if (customer != null && customer.getPassword().equals(password)) {
            return customer; // Return the customer if valid
        } else {
            return null; // Return null if invalid
        }
    }

//    public boolean validateCustomer(String customerNumber, String password) {
//        CustomerRegistration customer = customerDAO.getCustomerByNumber(customerNumber);
//        return customer != null && customer.getPassword().equals(password);
//    }
    
    // Fetch customer details by customer number
    public CustomerRegistration getCustomerDetails(String customerNumber) {
        return customerDAO.getCustomerByCustomerNumber(customerNumber);
    }

    // Update customer details
    public boolean updateCustomerDetails(CustomerRegistration updatedCustomer) {
        return customerDAO.updateCustomerDetails(updatedCustomer);
    }

    // Display customer details (helper method for confirmation)
    public void displayCustomerDetails(CustomerRegistration customer) {
        if (customer == null) {
            System.out.println("Customer not found.");
            return;
        }

        System.out.println("\n==========================================");
        System.out.println("        Customer Details");
        System.out.println("==========================================");
        System.out.println("Customer Number: " + customer.getCustomerNumber());
        System.out.println("Name: " + customer.getFirstName() + " " + customer.getMiddleName() + " " + customer.getSurname());
        System.out.println("Address: " + customer.getAddress() + ", " + customer.getArea() + ", " + customer.getAtPost());
        System.out.println("Taluka: " + customer.getTaluka() + ", District: " + customer.getDistrict());
        System.out.println("State: " + customer.getState() + ", Pincode: " + customer.getPincode());
        System.out.println("Electricity Number: " + customer.getElectricityNo());
        System.out.println("Initial Meter Reading: " + customer.getInitialMeterReading());
        System.out.println("==========================================\n");
    }
   
}




//    public boolean registerCustomer(CustomerRegistration registration) {
//        // Perform validations
//        if (registration.getFirstName() == null || registration.getFirstName().trim().isEmpty()) {
//            throw new IllegalArgumentException("First name cannot be empty.");
//        }

        //if (registration.getElectricityNo() == null || registration.getElectricityNo().trim().isEmpty()) {
        //    throw new IllegalArgumentException("Electricity number cannot be empty.");
        //}

        // Parse and validate initial meter reading
//        try {
//            int meterReading = Integer.parseInt(registration.getInitialMeterReading());
//            if (meterReading < 0) {
//                throw new IllegalArgumentException("Initial meter reading must be a positive number.");
//            }
//        } catch (NumberFormatException e) {
//            System.out.println("Error: Initial meter reading must be a valid number.");
//            return false;
//        }

//        // Validate pin code
//        if (registration.getPincode() <= 0) {
//            throw new IllegalArgumentException("Invalid Pincode.");
//        }

       

   

