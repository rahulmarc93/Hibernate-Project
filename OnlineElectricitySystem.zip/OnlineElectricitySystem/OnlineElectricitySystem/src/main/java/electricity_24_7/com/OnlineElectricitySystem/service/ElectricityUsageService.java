package electricity_24_7.com.OnlineElectricitySystem.service;

import java.time.LocalDate;
import java.util.List;

import electricity_24_7.com.OnlineElectricitySystem.entity.ElectricityUsage;

public interface ElectricityUsageService {

    List<ElectricityUsage> getUsage(String customerNumber);

    String addElectricityUsage(String customerNumber, double meterReading, LocalDate usageDate, double unitsConsumed);
}
