
package electricity_24_7.com.OnlineElectricitySystem.service;

import java.util.List;

import electricity_24_7.com.OnlineElectricitySystem.dao.ElectricityUsageDao;
import electricity_24_7.com.OnlineElectricitySystem.entity.ElectricityUsage;

public class ElectricityUsageService {


	    private final ElectricityUsageDao usageDao = new ElectricityUsageDao();

	    // Fetch usage data for a customer
	    public List<ElectricityUsage> getUsage(String customerNumber) {
	        return usageDao.getUsageByCustomerNumber(customerNumber);
	    }

	    // Display usage data in a tabular format
	    public void displayUsage(List<ElectricityUsage> usageList) {
	        if (usageList == null || usageList.isEmpty()) {
	            System.out.println("No electricity usage records found for the given customer.");
	            return;
	        }

	        System.out.println("\n==========================================");
	        System.out.println("         Electricity Usage Summary");
	        System.out.println("==========================================");
	        System.out.printf("%-15s %-15s %-15s%n", "Usage Date", "Units Used", "Customer Name");
	        System.out.println("------------------------------------------");

	        for (ElectricityUsage usage : usageList) {
	            System.out.printf("%-15s %-15.2f %-15s%n",
	                    usage.getUsageDate(),
	                    usage.getUnitsUsed(),
	                    usage.getCustomer().getFirstName() + " " + usage.getCustomer().getFirstName());
	        }

	        System.out.println("------------------------------------------");
	    }
	}

