package electricity_24_7.com.OnlineElectricitySystem.service;

import java.util.Scanner;

import electricity_24_7.com.OnlineElectricitySystem.entity.Meter;

public interface MeterService {

    boolean assignMeterToCustomer(Meter meter);

    static void addMeterInformation(Scanner scanner, String customerNumber) {
		// TODO Auto-generated method stub
		
	}
}
