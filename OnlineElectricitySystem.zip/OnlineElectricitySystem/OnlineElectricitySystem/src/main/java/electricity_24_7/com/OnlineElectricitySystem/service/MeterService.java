package electricity_24_7.com.OnlineElectricitySystem.service;

import electricity_24_7.com.OnlineElectricitySystem.dao.MeterDao;
import electricity_24_7.com.OnlineElectricitySystem.entity.Meter;

public class MeterService {

    private final MeterDao meterDao = new MeterDao();

    public boolean assignMeterToCustomer(Meter meter) {
        return meterDao.saveMeter(meter);
    }
}

