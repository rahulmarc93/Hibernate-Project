package electricity_24_7.com.OnlineElectricitySystem.service;

import java.util.List;
import electricity_24_7.com.OnlineElectricitySystem.entity.Bill;
import electricity_24_7.com.OnlineElectricitySystem.entity.PaymentHistory;

public interface PaymentHistoryService {

    void savePaymentHistory(Bill bill, double amountPaid, String paymentMethod);

    List<PaymentHistory> getPaymentHistoryByCustomer(String customerNumber);

	List<PaymentHistory> getHistory(String customerNumber);
}
