package electricity_24_7.com.OnlineElectricitySystem.service;

import java.util.List;

import electricity_24_7.com.OnlineElectricitySystem.dao.PaymentHistoryDao;
import electricity_24_7.com.OnlineElectricitySystem.entity.PaymentHistory;

public class PaymentHistoryService {
	private final PaymentHistoryDao paymentDao = new PaymentHistoryDao();

    public boolean savePayment(PaymentHistory payment) {
        return paymentDao.savePayment(payment);
    }
    // Retrieve payment history for a specific customer
    public List<PaymentHistory> getHistory(String customerNumber) {
        return paymentDao.getPaymentHistoryByCustomer(customerNumber);
    }

	public boolean processPayment(String customerNumber, double amount, String method) {
		// TODO Auto-generated method stub
		return false;
	}
	 // Display payment history in a readable tabular format
    public void displayPaymentHistory(List<PaymentHistory> history) {
        if (history == null || history.isEmpty()) {
            System.out.println("No payment history records found for the given customer.");
            return;
        }

        System.out.println("\n==========================================");
        System.out.println("           Payment History");
        System.out.println("==========================================");
        System.out.printf("%-15s %-15s %-15s %-15s%n", "Payment Date", "Amount Paid", "Payment Method", "Customer Name");
        System.out.println("------------------------------------------");

        for (PaymentHistory record : history) {
            System.out.printf("%-15s %-15.2f %-15s %-15s%n",
                    record.getPaymentDate(),
                    record.getAmountPaid(),
                    record.getPaymentMethod(),
                    record.getCustomer().getFirstName() + " " + record.getCustomer().getFirstName());
        }

        System.out.println("------------------------------------------");
    }
    
}

