package electricity_24_7.com.OnlineElectricitySystem.service.impl;

import electricity_24_7.com.OnlineElectricitySystem.dao.AdminDao;
import electricity_24_7.com.OnlineElectricitySystem.dao.BillDao;
import electricity_24_7.com.OnlineElectricitySystem.dao.CustomerDao;
import electricity_24_7.com.OnlineElectricitySystem.dao.MeterDao;
import electricity_24_7.com.OnlineElectricitySystem.dao.impl.AdminDaoImpl;
import electricity_24_7.com.OnlineElectricitySystem.dao.impl.BillDaoImpl;
import electricity_24_7.com.OnlineElectricitySystem.dao.impl.CustomerDaoImpl;
import electricity_24_7.com.OnlineElectricitySystem.dao.impl.MeterDaoImpl;
import electricity_24_7.com.OnlineElectricitySystem.entity.Bill;
import electricity_24_7.com.OnlineElectricitySystem.entity.CustomerRegistration;
import electricity_24_7.com.OnlineElectricitySystem.entity.Meter;
import electricity_24_7.com.OnlineElectricitySystem.service.AdminService;

import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.LocalDate;
import java.util.List;
import java.util.Scanner;

public class AdminServiceImpl implements AdminService {
    
	private static final Logger logger = LoggerFactory.getLogger(AdminServiceImpl.class);

    private AdminDao adminDAO = new AdminDaoImpl();
    private CustomerDao customerDao = new CustomerDaoImpl();
    private BillDao billDao = new BillDaoImpl();
    private MeterDao meterDao = new MeterDaoImpl();

    // Admin credentials
    private static final String username = "Admin";
    private static final String password = "Admin@123";

    // Validate Admin Credentials
    @Override
    public boolean validateAdmin(String username, String password) {
        return "Admin".equals(username) && "Admin@123".equals(password);
    }

    // Add Bill with input validation
    @Override
    public void addBill() {
        Scanner scanner = new Scanner(System.in);

        try {
            System.out.print("Enter Customer Number: ");
            String customerNumber = scanner.nextLine(); // Use nextLine() to handle alphanumeric input

            System.out.print("Enter Meter Number: ");
            String meterNumber = scanner.nextLine(); // Use nextLine() for alphanumeric input

            System.out.print("Enter Billing Amount: ");
            double amount = scanner.nextDouble();

            scanner.nextLine(); // Consume the leftover newline
            System.out.print("Enter Payment Status (Paid/Unpaid): ");
            String paymentStatus = scanner.nextLine();

            // Input validation
            if (amount <= 0) {
                System.out.println("Error: Billing amount must be greater than 0.");
                return;
            }

            if (!paymentStatus.equalsIgnoreCase("Paid") && !paymentStatus.equalsIgnoreCase("Unpaid")) {
                System.out.println("Error: Payment status must be either 'Paid' or 'Unpaid'.");
                return;
            }

            CustomerRegistration customer = customerDao.getCustomerByCustomerNumber(customerNumber);
            Meter meter = meterDao.findByMeterNumber(meterNumber);

            if (customer == null || meter == null) {
                System.out.println("Error: Invalid Customer Number or Meter Number.");
                return;
            }

            Bill bill = new Bill();
            bill.setCustomer(customer);
            bill.setMeter(meter);
            bill.setAmount(amount);
            bill.setBillingDate(LocalDate.now());
            bill.setPaymentStatus(paymentStatus);

            billDao.saveBill(bill); // Save the bill to the database
            System.out.println("Bill added successfully!");
        } catch (Exception e) {
            logger.error("Error while adding the bill: ", e);
            System.out.println("Error while adding the bill. Please try again.");
        } finally {
            scanner.close();
        }
    }

    @Override
    public CustomerRegistration getCustomerByNumber(String customerNumber) {
        return customerDao.getCustomerByCustomerNumber(customerNumber);
    }

    @Override
    public Meter getMeterByNumber(String meterNumber) {
        return meterDao.findByMeterNumber(meterNumber);
    }

    // Fetch All Customers
    @Override
    public List<CustomerRegistration> getAllCustomers() {
        return customerDao.getAllCustomers();
    }

    // Display Customers in Tabular Format
    @Override
    public void displayCustomers(List<CustomerRegistration> customers) {
        System.out.println("\n================================================================================");
        System.out.println("         Customer Information");
        System.out.println("=================================================================================");
        System.out.printf("%-10s %-25s %-25s %-20s%n", "CustID", "Full Name", "Electricity No", "Customer Number");
        System.out.println("------------------------------------------------------------------------------------");

        for (CustomerRegistration customer : customers) {
            String fullName = customer.getFirstName() + " " + customer.getMiddleName() + " " + customer.getSurname();
            System.out.printf("%-10d %-25s %-25s %-20s%n",
                    customer.getCustId(),
                    fullName,
                    customer.getElectricityNo(),
                    customer.getCustomerNumber());
        }

        System.out.println("------------------------------------------------------------------------------------");
    }

    // Fetch all bills
    @Override
    public List<Bill> getAllBills() {
        return billDao.getAllBills();
    }

    // Display bills in tabular format
    @Override
    public void displayBills(List<Bill> bills) {
        System.out.println("\n===========================================================================================");
        System.out.println("                                Bill Information");
        System.out.println("=========================================================================================");
        System.out.printf("%-10s %-15s %-15s %-15s %-15s %-10s%n",
                "Bill ID", "Customer Name", "Meter ID", "Billing Date", "Amount", "Payment Status");
        System.out.println("-----------------------------------------------------------------------------------------");

        for (Bill bill : bills) {
            System.out.printf("%-10d %-15s %-15s %-15s ₹%-10.2f %-15s%n",
                    bill.getBillId(),
                    bill.getCustomer().getFirstName() + " " + bill.getCustomer().getSurname(),
                    bill.getMeter().getMeterNumber(),
                    bill.getBillingDate(),
                    bill.getAmount(),
                    bill.getPaymentStatus());
        }

        System.out.println("-----------------------------------------------------------------------------------------");
    }

    // Generate a revenue report
    @Override
    public void generateReport() {
        List<Bill> bills = getAllBills();
        double totalRevenue = bills.stream()
                .mapToDouble(Bill::getAmount)
                .sum();

        long unpaidBills = bills.stream()
                .filter(bill -> !bill.getPaymentStatus().equalsIgnoreCase("Paid"))
                .count();

        System.out.println("\n==========================================");
        System.out.println("              Revenue Report");
        System.out.println("============================================");
        System.out.println("Total Bills Generated: " + bills.size());
        System.out.println("Total Revenue: ₹" + totalRevenue);
        System.out.println("Unpaid Bills: " + unpaidBills);
        System.out.println("============================================");
    }
}
