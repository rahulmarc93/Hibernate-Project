package electricity_24_7.com.OnlineElectricitySystem.service.impl;

import java.time.LocalDate;
import java.util.List;

import electricity_24_7.com.OnlineElectricitySystem.dao.BillDao;
import electricity_24_7.com.OnlineElectricitySystem.dao.impl.BillDaoImpl;
import electricity_24_7.com.OnlineElectricitySystem.entity.Bill;
import electricity_24_7.com.OnlineElectricitySystem.entity.PaymentHistory;
import electricity_24_7.com.OnlineElectricitySystem.service.BillService;
import org.hibernate.Session;
import org.hibernate.Transaction;
import electricity_24_7.com.OnlineElectricitySystem.util.HibernateUtil;

public class BillServiceImpl implements BillService {

    private final BillDao billDao = new BillDaoImpl();

    @Override
    public List<Bill> getUnpaidBills(String customerNumber) {
        return billDao.getOutstandingBills(customerNumber);
    }

    @Override
    public void payBill(int billId) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            Transaction transaction = session.beginTransaction();

            // Fetch the bill by its ID
            Bill bill = session.get(Bill.class, billId);
            if (bill != null && "Unpaid".equalsIgnoreCase(bill.getPaymentStatus())) {
                // Update the bill status to "Paid"
                bill.setPaymentStatus("Paid");
                session.update(bill);

                // Create and save a payment history record
                PaymentHistory paymentHistory = new PaymentHistory();
                paymentHistory.setPaymentDate(LocalDate.now());
                paymentHistory.setAmountPaid(bill.getAmount());
                paymentHistory.setCustomer(bill.getCustomer());

                session.save(paymentHistory); // Save the payment history record

                transaction.commit();
                System.out.println("Bill payment recorded successfully, and payment history updated.");
            } else if (bill == null) {
                System.out.println("Invalid Bill ID. Please try again.");
            } else {
                System.out.println("Bill is already paid.");
            }
        } catch (Exception e) {
            //e.printStackTrace();
        }
    }
}
