package electricity_24_7.com.OnlineElectricitySystem.service.impl;

import electricity_24_7.com.OnlineElectricitySystem.dao.CustomerDao;
import electricity_24_7.com.OnlineElectricitySystem.dao.impl.CustomerDaoImpl;
import electricity_24_7.com.OnlineElectricitySystem.entity.CustomerRegistration;
import electricity_24_7.com.OnlineElectricitySystem.service.CustomerService;

public class CustomerServiceImpl implements CustomerService {

    private final CustomerDao customerDAO = new CustomerDaoImpl();

    @Override
    public boolean registerCustomer(CustomerRegistration registration) {
        // Generate Customer Number: Prefix "CUST" + Auto-increment ID
        registration.setCustomerNumber("CUST" + System.currentTimeMillis() % 100000);
        return customerDAO.saveCustomerRegistration(registration);
    }

    @Override
    public CustomerRegistration validateCustomer(String customerNumber, String password) {
        CustomerRegistration customer = customerDAO.getCustomerByNumber(customerNumber);
        if (customer != null && customer.getPassword().equals(password)) {
            return customer; // Return the customer if valid
        } else {
            return null; // Return null if invalid
        }
    }

    @Override
    public CustomerRegistration getCustomerDetails(String customerNumber) {
        return customerDAO.getCustomerByCustomerNumber(customerNumber);
    }
}
