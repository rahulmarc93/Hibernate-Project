package electricity_24_7.com.OnlineElectricitySystem.service.impl;

import java.time.LocalDate;
import java.util.List;

import electricity_24_7.com.OnlineElectricitySystem.dao.CustomerDao;
import electricity_24_7.com.OnlineElectricitySystem.dao.ElectricityUsageDao;
import electricity_24_7.com.OnlineElectricitySystem.dao.impl.CustomerDaoImpl;
import electricity_24_7.com.OnlineElectricitySystem.dao.impl.ElectricityUsageDaoImpl;
import electricity_24_7.com.OnlineElectricitySystem.entity.CustomerRegistration;
import electricity_24_7.com.OnlineElectricitySystem.entity.ElectricityUsage;
import electricity_24_7.com.OnlineElectricitySystem.service.ElectricityUsageService;

public class ElectricityUsageServiceImpl implements ElectricityUsageService {

    private final ElectricityUsageDao electricityUsageDao = new ElectricityUsageDaoImpl();
    private final CustomerDao customerDao = new CustomerDaoImpl();

    @Override
    public List<ElectricityUsage> getUsage(String customerNumber) {
        return electricityUsageDao.getElectricityUsageByCustomerNumber(customerNumber);
    }

    @Override
    public String addElectricityUsage(String customerNumber, double meterReading, LocalDate usageDate, double unitsConsumed) {
        try {
            // Fetch the customer entity using customerNumber
            CustomerRegistration customer = customerDao.getCustomerByCustomerNumber(customerNumber);
            if (customer == null) {
                return "Error: Customer not found.";
            }

            // Create a new ElectricityUsage entity
            ElectricityUsage usage = new ElectricityUsage();
            usage.setMeterReading(meterReading);
            usage.setUsageDate(usageDate);
            usage.setUnitsConsumed(unitsConsumed);
            usage.setCustomer(customer);

            // Save the entity
            electricityUsageDao.saveElectricityUsage(usage);
            return "Electricity usage added successfully!";
        } catch (Exception e) {
            //e.printStackTrace();
            return "Error: Unable to add electricity usage.";
        }
    }
}
