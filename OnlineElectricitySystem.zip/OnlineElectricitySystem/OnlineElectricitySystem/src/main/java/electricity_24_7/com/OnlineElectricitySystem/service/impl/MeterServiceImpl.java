package electricity_24_7.com.OnlineElectricitySystem.service.impl;

import java.util.Scanner;

import electricity_24_7.com.OnlineElectricitySystem.dao.MeterDao;
import electricity_24_7.com.OnlineElectricitySystem.dao.impl.MeterDaoImpl;
import electricity_24_7.com.OnlineElectricitySystem.entity.Meter;
import electricity_24_7.com.OnlineElectricitySystem.service.MeterService;

public class MeterServiceImpl implements MeterService {

    private final static MeterDao meterDao = new MeterDaoImpl();

    @Override
    public boolean assignMeterToCustomer(Meter meter) {
        return meterDao.saveMeter(meter);
    }
    
    public void addMeterInformation(Scanner scanner, String customerNumber) {
        System.out.println("\n==========================================");
        System.out.println("        Add Meter Information");
        System.out.println("==========================================");

        System.out.print("Enter Meter Number: ");
        String meterNumber = scanner.nextLine(); // Meter number input

        System.out.print("Enter Installation Date (yyyy-mm-dd): ");
        String installationDate = scanner.nextLine(); // Installation date input

        System.out.print("Enter Meter Status (ACTIVE/INACTIVE): ");
        String status = scanner.nextLine(); // Meter status input

        // Call the MeterDao to add the meter using the instance of MeterDao
        String result = meterDao.addMeterInfo(customerNumber, meterNumber, installationDate, status);

        // Display the result of adding the meter (full meter details)
        System.out.println("\nMeter Information Added Successfully:");
        System.out.println(result);
    }
}
