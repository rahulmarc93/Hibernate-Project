package electricity_24_7.com.OnlineElectricitySystem.service.impl;

import java.util.List;

import electricity_24_7.com.OnlineElectricitySystem.dao.PaymentHistoryDao;
import electricity_24_7.com.OnlineElectricitySystem.dao.impl.PaymentHistoryDaoImpl;
import electricity_24_7.com.OnlineElectricitySystem.entity.Bill;
import electricity_24_7.com.OnlineElectricitySystem.entity.PaymentHistory;
import electricity_24_7.com.OnlineElectricitySystem.service.PaymentHistoryService;

public class PaymentHistoryServiceImpl implements PaymentHistoryService {

    private PaymentHistoryDao paymentHistoryDao;

    // Constructor to initialize the DAO
    public PaymentHistoryServiceImpl() {
        this.paymentHistoryDao = new PaymentHistoryDaoImpl();
    }

    @Override
    public void savePaymentHistory(Bill bill, double amountPaid, String paymentMethod) {
        paymentHistoryDao.savePaymentHistory(bill, amountPaid, paymentMethod);
    }

    @Override
    public List<PaymentHistory> getPaymentHistoryByCustomer(String customerNumber) {
        return paymentHistoryDao.getPaymentHistoryByCustomer(customerNumber);
    }

	@Override
	public List<PaymentHistory> getHistory(String customerNumber) {
		// TODO Auto-generated method stub
		return null;
	}
}